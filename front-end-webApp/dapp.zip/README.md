After pulling all the codes within front-end folder to your local machine --- 

  1) make sure you have node.js (npm) installed (https://nodejs.org/en/download/)
  2) install express package: open up terminal, input "npm install express --save"
  3) cd into the front-end folder, and input "node server.js", and you will see "port is open on 8082" 
  4) open chrome - "http://127.0.0.1:8082/" 
